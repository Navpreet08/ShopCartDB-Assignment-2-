/**
 * Created by championswimmer on 13/06/17.
 */

module.exports = {
    TODO_FILE: __dirname + "/todos.txt"
};