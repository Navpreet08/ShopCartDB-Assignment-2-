const Sequelize = require('sequelize');
const db = new Sequelize('shopcartDB', 'root', 'mypass', {
    host: 'localhost',
    dialect: 'mysql',
    pool: {
        max: 5,
        min: 0,
        idle: 5000
    }
});

const Todo = db.define('todo', {
    id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    pid: {
        type: Sequelize.INTEGER,
        foreignKey: true,
    },
    item: Sequelize.STRING,
    price: Sequelize.INTEGER,
    quantity: Sequelize.INTEGER,
    subTotal: Sequelize.INTEGER
});

const Product = db.define('product', {
    productId: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    image: Sequelize.STRING,
    item: Sequelize.STRING,
    para: Sequelize.STRING,
    price: Sequelize.INTEGER
});

db.sync({});

function getTodos () {
    return Todo.findAll()
}

function addTodo (todo) {
    return Todo.create({
        pid: todo.pid,
        item: todo.item,
        price: todo.price,
        quantity: todo.quantity,
        subTotal: todo.subTotal
    })
}

function getProducts () {
    return Product.findAll()
}

function deleteTodo(todo) {
    return Todo.destroy({
        where: {
            id: todo.tid
        }
    })
}

function quanAndStotalTodo(todo) {
    return Todo.update({
        subTotal: todo.subTotal,
        quantity: todo.quantity
    }, {
        fields: ['subTotal', 'quantity'],
        where: {
            id: todo.tid
        }
    }).then(() => {})
}

function clearTodo(todo) {
    return Todo.destroy({ truncate: true })
}

module.exports = {
    getTodos,
    addTodo,
    getProducts,
    deleteTodo,
    quanAndStotalTodo,
    clearTodo
};