/**
 * Created by championswimmer on 12/06/17.
 */

$(function () {

    function refreshProducts(products) {
        var productList = "", quan = 1;
        for(var product of products) {
            productList += '<div class="col-sm-4 col-xs-12" align="center">'+
                '<figure class="snip1246 wow zoomIn">'+
                    '<img src="'+ product.image +'" alt="'+ product.image +'" class="img-responsive"/>'+
                    '<figcaption>'+
                        '<h2>'+ product.item +'</h2>'+
                        '<p>'+ product.para +'</p>'+
                        '<div class="price">$'+ product.price +'.00</div>'+
                        '<input type="submit" value="Add to Cart" class="addCart" pid="'+ product.productId +'" item="'+ product.item +'" price="'+ product.price +'" quantity="'+ quan +'" sub-total="'+ product.price +'"/>'+
                    '</figcaption>'+
                '</figure>'+
            '</div>';
        }
        $('#productList').html(productList);
    }

    function refreshCarts(carts) {
        var cartlist = "", i = 0, sum = 0;

        for (var cart of carts) {
            cartlist += '<tr>' +
                '<td>' + (i+1) + '</td>' +
                '<td>' + cart.item + '</td>' +
                '<td>$' + cart.price + '.00</td>' +
                '<td>'+
                    '<input type="submit" value="+" class="todoIncr" todoid="'+ cart.id +'" price="'+ cart.price +'" subTotal="'+ cart.subTotal +'" quantity="'+ cart.quantity +'"/>&nbsp;&nbsp;&nbsp;' + 
                    cart.quantity + 
                    '&nbsp;&nbsp;&nbsp;<input type="submit" value="-" class="todoDecr" todoid="'+ cart.id +'" price="'+ cart.price +'" subTotal="'+ cart.subTotal +'" quantity="'+ cart.quantity +'"/>'+
                '</td>' +
                '<td>$' + cart.subTotal + '.00</td>' +
                '<td><input type="submit" value="Remove" class="deleteCart" todoid="'+ cart.id +'"/></td>' +
            '</tr>';
            i++;
            sum += cart.subTotal;
        }
        $('#cartList').html(cartlist);
        if(carts.length >= 1) {
            $("#totalRow").css("display", "");
            document.getElementById('totalValue').innerHTML = "$" + sum + ".00";
        } else {
            $("#totalRow").css("display", "none");
        }
    }

    $.get('/api/todos/product', function (data) {
        refreshProducts(data)
    });

    $.get('/api/todos', function (data) {
        refreshCarts(data)
    });

    $(document).on('click', '.updateCart', function() {
        
        $.get('/api/todos', function (data) {
            if (data.length >= 1) {
                alert("Your cart is up to date :)");
            } else {
                alert("Your cart is empty :(");
            }
        });
    });

    $(document).on('click', '.checkoutCart', function() {

        $.get('/api/todos', function (data) {
            if (data.length >= 1) {
                clearCart();
                alert("Thank you for shopping :)\nYour total shopping amount is " + $("#totalValue").html());
                window.close();
            } else {
                alert("Your cart is empty :(");
            }
        });
    });

    $(document).on('click', '.clearCart', function() {
        $.get('/api/todos', function (data) {
            if (data.length >= 1) {
                clearCart();
            } else {
                alert("Your cart is empty :(");
            }
        });
    });

    function clearCart() {
        $.post('/api/todos/clear', {
            clear: 1
        }, function (data) {
            refreshCarts(data)
        })
    }

    $(document).on('click', '.todoIncr', function() {
        
        var incrtodo = {
            tid: $(this).attr('todoid'),
            price: $(this).attr('price'),
            subTotal: $(this).attr('subTotal'),
            quantity: $(this).attr('quantity')
        };

        var totalSum = parseInt(incrtodo.price) + parseInt(incrtodo.subTotal);
        incrtodo.subTotal = totalSum;
        incrtodo.quantity = parseInt(incrtodo.quantity) + 1;

        quanAndStotalCart(incrtodo);
    });

    $(document).on('click', '.todoDecr', function() {
        
        var flag = 0;

        var decrtodo = {
            tid: $(this).attr('todoid'),
            price: $(this).attr('price'),
            subTotal: $(this).attr('subTotal'),
            quantity: $(this).attr('quantity')
        };

        decrtodo.quantity = parseInt(decrtodo.quantity) - 1;

        if (decrtodo.quantity >= 1) {
            var totalSum = parseInt(decrtodo.subTotal) - parseInt(decrtodo.price);
            decrtodo.subTotal = totalSum;

            quanAndStotalCart(decrtodo);
        } else {
            alert("Quantity can't be zero :(");
        }
    });

    function quanAndStotalCart(quanAndStotaltodo) {
        $.post('/api/todos/quanAndStotal', {
            quanAndStotaltodo
        }, function (data) {
            refreshCarts(data)
        })
    }


    $(document).on('click', '.deleteCart', function() {
        
        var deltodo = {
            tid: $(this).attr('todoid')
        };
        $.post('/api/todos/del', {
            deltodo
        }, function (data) {
            refreshCarts(data)
        })
    });


    $(document).on('click', '.addCart', function() {
        
        var flag = 0;
        var newtodo = {
            pid: $(this).attr('pid'),
            item: $(this).attr('item'),
            price: $(this).attr('price'),
            quantity: $(this).attr('quantity'),
            subTotal: $(this).attr('sub-total')
        };

        $.get('/api/todos', function (data) {
            for(var todo of data) {
                if(todo.pid == newtodo.pid) {
                    flag = 1;
                    break;
                }
            }
            insertCart(flag, newtodo);
        });
    });

    function insertCart(flag, newtodo) {

        if(flag == 0) {
            alert(newtodo.item + " is inserted in your cart :)");
            $.post('/api/todos/new', {
                newtodo
            }, function (data) {
                refreshCarts(data)
            })
        } else {
            alert(newtodo.item + " already exists in your cart.");
        } 
    }

});