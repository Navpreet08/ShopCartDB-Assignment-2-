const route = require('express').Router();
const data = require('../data');

route.get('/product', (req, res) => {

    data.getProducts().then((results) => {
        res.send(results)
    })

});
route.get('/', (req, res) => {

    data.getTodos().then((results) => {
        res.send(results)
    })

});

route.post('/new', (req, res) => {

    data.addTodo(req.body.newtodo).then(()=> {
        res.redirect('/api/todos')
    }).catch((err) => {
        res.send(err)
    })
});

route.post('/del', (req, res) => {

    data.deleteTodo(req.body.deltodo).then(()=> {
        res.redirect('/api/todos')
    }).catch((err) => {
        res.send(err)
    })
});

route.post('/quanAndStotal', (req, res) => {

    data.quanAndStotalTodo(req.body.quanAndStotaltodo).then(()=> {
        res.redirect('/api/todos')
    }).catch((err) => {
        res.send(err)
    })
});

route.post('/clear', (req, res) => {

    data.clearTodo(req.body.clear).then(()=> {
        res.redirect('/api/todos')
    }).catch((err) => {
        res.send(err)
    })
});

module.exports = route;